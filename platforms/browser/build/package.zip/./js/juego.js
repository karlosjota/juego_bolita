/* 
 * juego Modulo 04 - MiriadaX, librería Phaser
 * 
 * By: @karlosjota
 *
 */
 var app = {
 	inicio: function() {
 		DIAMETRO_BOLA = 50;
 		// Tamaño del dispositivo 
 		alto = document.documentElement.clienteHeight;
 		ancho = document.documentElement.clienteWidth;
 		// funciones de detectióon de la agitación y de inicio del juego
 		app.vigilaSensores();
 		app.iniciaJuego();
 	},

 	iniciaJuego: function() {
 		// primer estado de ciclo de juego
 		function preload() {
 			game.physics.startSystem(Phaser.Physics.ARCADE);
 			game.stage.backgroundColor = '#F27D0C';
 			// alias y localización
 			game.load.image('bola', 'assets/bola.png');
 		}
 		// se cargan los parameros preparados en preload en el segundo ciclo del juego
 		function create() {
 			// añadimos sprite y le dicemos donde inicia
 		bola = game.add.sprite(app.inicioX(), app.inicioY(), 'bola');
 		game.physics.arcade.enable(bola);

 		}
 	
 	function update() {
 		// resta los 9,8 newton de la grabedad de la tierra 
 		bola.body.velocity.y  (velocidadY * 300);
 		bola.body.velocitx.x  (velocidadX * 300);

 	}

 	// para los dos primeros estados usamos sus dos respectivas funciones 
 		var estados = { preload: preload, create: create };
 		// se carga la libreria phaser y se almacena en la variable game, se renderizará en phaser.canvas, en el elemento con el id 'phaser' y le pasamos el mapa de estados con sus dos funciones cargadas
 		var game = new Phaser.Game(ancho, alto, Phaser.CANVAS, 'phaser', estados);

},
 	// localización de inicio de la bola
 	inicioX: function() {
 		// numero aleatorio entre el ancho del canvas menos el diḿatro de la bola 
 		return app.numeroAleatorioHasta(ancho - DIAMETRO_BOLA);
 	},

 	inicioY: function() {
 		return app.numeroAleatorioHasta(alto - DIAMETRO_BOLA);
 	},

 	numeroAleatorioHasta: function(limite) {
 		// redondeo del número aleatorio
 		return Math.floor(Math.random() * limite);
 	},

 	vigilaSensores: function() {

 		function onError() {
 			console.log('onEror!');
 		}

 		function onSuccess(datosAceleracion) {
 			app.detectaAgitacion(datosAceleracion);
 		}
 		// frecuencia con la que rastreará la agitación en milisegundos
 		navigator.accelorometer.watchAcceleration(onSuccess, onEror, { frequency: 1000 });
 	},

 	detectaAgitacion: function(datosAceleracion) {

 		var agitacionX = datosAceleracion.x > 10;
 		var agitacionY = datosAceleracion.y > 10;
 	}
 }

